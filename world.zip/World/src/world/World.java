/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package world;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Admin
 */
public class World {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        // TODO code application logic here
        DBConnector db = new DBConnector();
        String sql = "SELECT countrycode, cityname, id From world.city";
        Statement stmt = db.getConnection().createStatement();
        ResultSet rs = stmt.executeQuery(sql);
        
       
        ArrayList<City> cityList = new ArrayList<>();
        
        while (rs.next()) {     
           
            String ccode = rs.getString("cityname");
            int id = rs.getInt("id");
           
            System.out.println(id+" "+ccode);
            
            City city = new City(id, ccode);
            cityList.add(city);
            
        }
        
    }
    
}
