package teamwork;

import java.util.ArrayList;

public class DataAccessObject_impl {
    private DBConnector connector = null;

    DataAccessObject_impl(DBConnector connector) {
        this.connector = connector;
    }

    public ArrayList<User> getTeamMembers(int team_id) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public ArrayList<Team> getTeams() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Team getTeam(int id) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Team getTeam(String teamname) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public ArrayList<User> getUsers() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public User getUser(int id) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public User getUser(String username) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
 
}
